from django.shortcuts import render,redirect
from django.contrib import messages
from mainapp.models import *

# Create your views here.
def userdash(request):
    if not 'userid' in request.session:
        messages.error(request, "you are not logged in .")
        return redirect('login')
    userid = request.session.get('userid')
    user = Userinfo.objects.get(email=userid)
    context = {
        'userid' : userid,
        'user':user,
    }
        
    return render(request, 'userdash.html',context)



def userlogout(request):
    if 'userid' in request.session:
        del request.session['userid']
        messages.success(request, "You are logged out Successfully.")
        return redirect('index')
    else:
        messages.warning(request, "Smoething went wrong")
    return redirect('index')
