from django.urls import path
from . import views


urlpatterns = [
    path('userdash/',views.userdash, name='userdash'),
   

]